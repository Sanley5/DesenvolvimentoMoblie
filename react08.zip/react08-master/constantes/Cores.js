export default {
    primary: 'green'
}