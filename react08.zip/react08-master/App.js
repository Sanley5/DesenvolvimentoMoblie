import React from 'react';
import LugaresNavigator from './navegacao/LugaresNavigator'

export default function App() {
  return <LugaresNavigator/>
}


