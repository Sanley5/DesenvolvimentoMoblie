import React from 'react';

import { View, StyleSheet, Text } from 'react-native';


const MapaTela = (props) => {
    return (
        <View>
            {MapaTela}
        </View>
    )
}

const estilos = StyleSheet.create({});

export default MapaTela;