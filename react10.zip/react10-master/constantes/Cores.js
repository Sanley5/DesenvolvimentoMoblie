export default {
    primary: '#green'
}