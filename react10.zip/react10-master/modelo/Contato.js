class Contato {
    constructor(id, nome,telefone, imagemURI) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.imagemURI = imagemURI;
    }
}

export default Contato;